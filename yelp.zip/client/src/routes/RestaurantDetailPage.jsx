import React from 'react'

export const RestaurantDetailPage = () => {
  return (
    <div>Detail Page</div>
  )
}

export default RestaurantDetailPage