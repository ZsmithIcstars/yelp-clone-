const { Pool } = require("pg");

const dbPool = new Pool();

module.exports = {
  query: (text, params) => dbPool.query(text, params),
};
